#!/usr/bin/env python
# coding: utf-8

# In[1]:


from bs4 import BeautifulSoup
import requests
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import plotly.graph_objs as go
import plotly.express as px
from pandasql import sqldf


# In[2]:


#Extracting/scraping an HTML site
url ='https://en.wikipedia.org/wiki/List_of_best-selling_singles'
page = requests.get(url)
soup = BeautifulSoup(page.text , 'html')


# In[3]:


table = soup.find_all('table')[1]


# In[4]:


world_titles = table.find_all('th')


# In[5]:


world_table_titles = [title.text.strip() for title in world_titles] 


# In[6]:


#display the Column names
df = pd.DataFrame(columns = world_table_titles)
df


# In[7]:


column_data = table.find_all('tr')


# In[8]:


#itarating the the table rows to collect the information
for row in column_data[1:]:
    row_data = row.find_all('td')
    individual_row_data = [data.text.strip() for data in row_data]
    
    length = len(df)
    df.loc[length] = individual_row_data


# In[9]:


def clean_and_convert_sales(value):
    try:
        # Remove any non-numeric characters, and then convert to float
        value = float(value.replace('[disputed – discuss]', ''))
    except (ValueError, AttributeError):
        # Handle the case where the conversion fails
        value = None
    return value

# Apply the custom function to clean and convert the column
df['Sales(in millions)'] = df['Sales(in millions)'].apply(clean_and_convert_sales)

# Verify the data types after conversion
data_types = {'Artist': str, 'Single': str, 'Released': int, 'Sales(in millions)': float}
df = df.astype(data_types)
df.info()


# In[10]:


#subsetting the colums to extract the info from
df=df[['Artist','Single','Released','Sales(in millions)']]
df


# In[11]:


#Extacting the most sold singles 
Most_sold=df.head(15)
Most_sold


# In[12]:


#Diplay the Top 15 most sold single 
fig = px.pie(Most_sold, names="Artist", values="Sales(in millions)",title="Top 15 most sold single")

# Show the pie chart
fig.show()


# In[13]:


# Create a histogram using Plotly Express
#fig = px.histogram(df, x='Released', nbins=10, title="Single Released ten years")
# Create the histogram with different colors for each bar
fig = px.histogram(df, x='Released', nbins=10, color='Released', title="Single Released ten years")
# Show the plot
fig.show()


# In[ ]:





# In[ ]:




